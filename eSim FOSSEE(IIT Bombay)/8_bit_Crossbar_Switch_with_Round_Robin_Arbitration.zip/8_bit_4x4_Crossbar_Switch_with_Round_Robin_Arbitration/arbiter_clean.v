module arbiter_clean (
    input clk,
    input rst,
    input [3:0] req,    // Requests from Ports 1-4
    output reg [3:0] gnt // Grant signals to the Crossbar
);

reg [1:0] state;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        gnt <= 4'b0000;
        state <= 2'b00;
    end else begin
        gnt <= 4'b0000;
        case (state)
            2'b00: begin // Port 1 has priority
                if (req[0]) begin gnt[0] <= 1; state <= 2'b01; end
                else if (req[1]) begin gnt[1] <= 1; state <= 2'b10; end
                else if (req[2]) begin gnt[2] <= 1; state <= 2'b11; end
                else if (req[3]) begin gnt[3] <= 1; state <= 2'b00; end
            end
            2'b01: begin // Port 2 has priority
                if (req[1]) begin gnt[1] <= 1; state <= 2'b10; end
                else if (req[2]) begin gnt[2] <= 1; state <= 2'b11; end
                else if (req[3]) begin gnt[3] <= 1; state <= 2'b00; end
                else if (req[0]) begin gnt[0] <= 1; state <= 2'b01; end
            end
            2'b10: begin // Port 3 has priority
                if (req[2]) begin gnt[2] <= 1; state <= 2'b11; end
                else if (req[3]) begin gnt[3] <= 1; state <= 2'b00; end
                else if (req[0]) begin gnt[0] <= 1; state <= 2'b01; end
                else if (req[1]) begin gnt[1] <= 1; state <= 2'b10; end
            end
            2'b11: begin // Port 4 has priority
                if (req[3]) begin gnt[3] <= 1; state <= 2'b00; end
                else if (req[0]) begin gnt[0] <= 1; state <= 2'b01; end
                else if (req[1]) begin gnt[1] <= 1; state <= 2'b10; end
                else if (req[2]) begin gnt[2] <= 1; state <= 2'b11; end
            end
        endcase
    end
end
endmodule

